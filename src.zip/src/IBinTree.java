import java.lang.Math;
import java.util.LinkedList;

interface IBinTree {
 // determines whether element is in the tree
 boolean hasElt(int e);
 // returns number of nodes in the tree; counts duplicate elements as separate items
 int size();
 // returns depth of longest branch in the tree
 int height();

 int getOccurrence(int e);

 LinkedList<Integer> elementsList();

 boolean isHeap(int e, boolean check);
}

class MtBT implements IBinTree {
 MtBT(){}

 // returns false since empty tree has no elements
 public boolean hasElt(int e) {
  return false;
 }

 // returns 0 since enpty tree has no elements
 public int size() {
  return 0;
 }

 // returns 0 since empty tree has no branches
 public int height() {
  return 0;
 }

 /**
  * Counts how many times a certain element appears in a heap
  * @param e Number you want to check for
  * @return Amount of times element occurs in heap
  */
 public int getOccurrence(int e) {return 0;}

 public LinkedList<Integer> elementsList()
 {
  return new LinkedList<Integer>();
 }

 /**
  * Checks to see if a given binary search tree is a valid heap
  * @param e represents the current data value, used in recursion
  * @return True if binary tree is a heap
  */
 public boolean isHeap(int e, boolean check) {
  return true;
 }

}

class DataBT implements IBinTree {
 int data;
 IBinTree left;
 IBinTree right;

 DataBT(int data, IBinTree left, IBinTree right) {
  this.data = data;
  this.left = left;
  this.right = right;
 }

 // an alternate constructor for when both subtrees are empty
 DataBT(int data) {
   this.data = data;
   this.left = new MtBT();
   this.right = new MtBT();
 }

 // determines whether this node or node in subtree has given element
 public boolean hasElt(int e) {
  return this.data == e || this.left.hasElt(e) || this.right.hasElt(e) ;
 }

 // adds 1 to the number of nodes in the left and right subtrees
 public int size() {
  return 1 + this.left.size() + this.right.size();
 }

 // adds 1 to the height of the taller subtree
 public int height() {
  return 1 + Math.max(this.left.height(), this.right.height());
 }

 public boolean isBigger(int e) {
  return (this.data >= e);
 }


 /**
  * Parses a BT into a linked list
  * @return Linked list of elements of a binary tree
  */
 public LinkedList<Integer> elementsList()
 {
  LinkedList<Integer> temp = new LinkedList<Integer>();
  temp.add(data);
  temp.addAll(this.left.elementsList());
  temp.addAll(this.right.elementsList());
  return temp;
 }

 /**
  * Counts how many times a certain element appears in a heap
  * @param e Number you want to check for
  * @return Amount of times element occurs in heap
  */
 public int getOccurrence(int e)
 {
  if (this.data == e)
  {
   return 1+ this.left.getOccurrence(e) + this.right.getOccurrence(e);
  }

  else
  {
   return this.left.getOccurrence(e) + this.right.getOccurrence(e);
  }
 }

 /**
  * Checks to see if a given binary search tree is a valid heap
  * @param e represents the current data value, used in recursion
  * @return True if binary tree is a heap
  */
 public boolean isHeap(int e, boolean check)
 {
  boolean lessCheck = true;
  if (check == true)
  {
   lessCheck = this.data >= e;
  }
  return (lessCheck && this.left.isHeap(this.data, true) && this.right.isHeap(this.data, true));
 }

}
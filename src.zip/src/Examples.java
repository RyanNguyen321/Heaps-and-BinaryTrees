import org.junit.Test;


import static org.junit.Assert.*;

public class Examples {
    MtHeap mtHeap = new MtHeap();
    HeapChecker heapChecker = new HeapChecker();


    @Test
    public void testHeap_1()
    {
        assertTrue(mtHeap.isHeap(0, false));
    }

    @Test
    public void testHeap_2()
    {
        DataHeap heap1 = new DataHeap(50, new DataHeap(40, mtHeap, mtHeap), mtHeap);
        assertFalse(heap1.isHeap(0, false));
    }

    @Test
    public void testHeap_3()
    {
        DataHeap heap1 = new DataHeap(40, new DataHeap(50, mtHeap, mtHeap), mtHeap);
        assertTrue(heap1.isHeap(0, false));
    }

    @Test
    public void testisHeap_4()
    {
        DataHeap heap1 = new DataHeap(50, new DataHeap(50, mtHeap, mtHeap), mtHeap);
        assertTrue(heap1.isHeap(0, false));
    }

    @Test
    public void testisHeap_5()
    {
        DataHeap heap1 = new DataHeap(40, new DataHeap(50, new DataHeap(50 , mtHeap, mtHeap), mtHeap), mtHeap);
        assertTrue(heap1.isHeap(0, false));
    }

    @Test
    public void testHeap_6()
    {
        DataHeap heap1 = new DataHeap(50, new DataHeap(40, new DataHeap(50 , mtHeap, mtHeap), mtHeap), mtHeap);
        assertFalse(heap1.isHeap(0, false));
    }

    @Test
    public void testisHeap_7()
    {
        DataHeap heap1 = new DataHeap(50, new DataHeap(40, new DataHeap(40 , mtHeap, mtHeap), mtHeap), mtHeap);
        assertFalse(heap1.isHeap(0, false));
    }

    @Test
    public void testisHeap_8()
    {
        DataHeap heap1 = new DataHeap(50, new DataHeap(50, new DataHeap(50 , mtHeap, mtHeap), mtHeap), mtHeap);
        assertTrue(heap1.isHeap(0, false));
    }

    @Test
    public void countElt_1()
    {
        assertEquals(mtHeap.getOccurrence(3), 0 );
    }

    /*              50
                   /  \
                 40    50
                /  \   / \
              30   50 60  70

     */
    @Test
    public void countElt_2()
    {
        DataHeap heap1 = new DataHeap(50, new DataHeap (40, new DataHeap(30, mtHeap, mtHeap), new DataHeap(50, mtHeap, mtHeap)), (new DataHeap(50, new DataHeap(60, mtHeap, mtHeap),  new DataHeap(70, mtHeap, mtHeap))));
        assertEquals(heap1.getOccurrence(50), 3 );
        assertEquals(heap1.getOccurrence(30), 1 );
        assertEquals(heap1.getOccurrence(20), 0 );
    }

    @Test
    public void addremoveEltCheck_1()
    {
        TestHeap heap1 = new TestHeap(50, new DataHeap(60, mtHeap, mtHeap), mtHeap);
        assertFalse(heapChecker.addEltTester(heap1,90,heap1.addElt(90)));
    }

    @Test
    public void addremoveEltCheck_2()
    {
        TestHeap2 heap1 = new TestHeap2(50, new DataHeap(60, mtHeap, mtHeap), mtHeap);
        assertFalse(heapChecker.remMinEltTester(heap1,new DataHeap(60, mtHeap, mtHeap)));
    }

    @Test
    public void addremoveEltCheck_3()
    {
        TestHeap3 heap1 = new TestHeap3(50, new DataHeap(60, mtHeap, mtHeap), mtHeap);
        assertFalse(heapChecker.addEltTester(heap1, 40 , new DataHeap(50 , new DataHeap(40 ,mtHeap ,mtHeap), new DataHeap(60, mtHeap, mtHeap))));
    }

    @Test
    public void addremoveEltCheck_4()
    {
        TestHeap4 heap1 = new TestHeap4(50, new DataHeap(60, mtHeap, mtHeap), mtHeap);
        assertFalse(heapChecker.remMinEltTester(heap1, new DataHeap(60, mtHeap, mtHeap)));
    }

    @Test
    public void addremoveEltCheck_5()
    {
        TestHeap5 heap1 = new TestHeap5(50, new DataHeap(60, mtHeap, mtHeap), mtHeap);
        assertFalse(heapChecker.addEltTester(heap1, 40, new DataHeap(50 , new DataHeap(40 ,mtHeap ,mtHeap), new DataHeap(60, mtHeap, mtHeap))));
    }


}

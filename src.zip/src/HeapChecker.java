import org.junit.Test;

import java.util.LinkedList;

public class HeapChecker {
    HeapChecker()  {}
    //1.) Check if the heap is valid
    //  Root is smallest element and subtrees are all heaps
    //2.) Heap contains all original elements and has same number of occurences
    //3.) Ensure that no extra elements are added/missing

    /**
     * Checks to see if the function addElt works correctly, that the added element to a binary tree creates a heap that is a possible solution
     * @param hOrig Original heap we compare
     * @param elt Element that is added
     * @param hAdded Binary tree that the element is added to
     * @return True if the heap is a valid solution
     */

    boolean addEltTester(IHeap hOrig, int elt, IBinTree hAdded) {
        //Variables
        boolean countCheck = true;
        LinkedList<Integer> listOfFinElts = hAdded.elementsList();

        //step 1 check if added heap is valid
        if ( hAdded.isHeap(0, false))
        {   //go thru each element and check if it matches for added element
            for (int element: listOfFinElts)
            {
                if (element == elt)
                {   //if it does match element check occurence of said element, check if it is added or removed once to many times
                    if (hOrig.getOccurrence(element)  + 1 != hAdded.getOccurrence(element))
                    {
                        countCheck  = false;
                    }
                }
                else if (hOrig.getOccurrence(element) != hAdded.getOccurrence(element))
                {
                    countCheck  = false;
                }
            }
            return (countCheck == true && (hOrig.size() +1 == hAdded.size()));
        }

        else
        {
            return false;
        }
    }


    /**
     * Checks if function remElt works, that removing the minimum element from a Heap creates a valid solution
     * @param hOrig Original heap that is compared
     * @param hRemoved Heap with removed min element
     * @return True if the heap with a removed element is a valid solution
     */
    boolean remMinEltTester(IHeap hOrig, IBinTree hRemoved) {
        boolean countCheck = false;
        LinkedList<Integer> initialElements = hOrig.elementsList();
        if (hRemoved.isHeap(0,false))
        {
            for (int element: initialElements)
            {
                if (initialElements.get(0) == element)
                {
                    if (hOrig.getOccurrence(element) + 1 != hRemoved.getOccurrence(element))
                    {
                        countCheck = true;
                    }
                }
                else  if (hOrig.getOccurrence(element) + 1 != hRemoved.getOccurrence(element))
                {
                    countCheck = true;
                }
            }
            return (countCheck == false && (hOrig.size() +1 == hRemoved.size()));
        }
        else
            return false;
    }



}
